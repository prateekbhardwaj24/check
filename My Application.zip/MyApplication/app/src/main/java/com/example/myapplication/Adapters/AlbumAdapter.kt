package com.example.myapplication.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.musicplayer.Modals.AudioModal
import com.example.myapplication.Modals.AlbumsModal
import com.example.myapplication.R

class AlbumAdapter: RecyclerView.Adapter<AlbumAdapter.MyViewHolder>() {
    private var allSongList: ArrayList<AlbumsModal> = ArrayList()
    private lateinit var context: Context

    fun addAlbums(context: Context, songList: ArrayList<AlbumsModal>) {
        this.allSongList = songList
        this.context = context
        notifyDataSetChanged()
    }
    class MyViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
         var songName: TextView
        lateinit var songArtist: TextView
        lateinit var imageAl:ImageView

        init {
            songName = itemView.findViewById(R.id.albumName)
            songArtist = itemView.findViewById(R.id.albumArtist)
            imageAl = itemView.findViewById(R.id.imageAlbum)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.album_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var dataModal = allSongList.get(position)
        holder.songName.text = dataModal.albumName
        holder.songArtist.text = dataModal.artistName
        Glide.with(context).load(dataModal.albumArt).apply(RequestOptions().placeholder(R.drawable.im).centerCrop()).into(holder.imageAl)

    }

    override fun getItemCount(): Int {
        return allSongList.size
    }
}