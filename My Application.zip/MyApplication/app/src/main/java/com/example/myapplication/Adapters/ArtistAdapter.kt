package com.example.myapplication.Adapters

import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.musicplayer.Modals.FolderModal
import com.example.myapplication.Modals.ArtistsModal
import com.example.myapplication.R
import com.example.myapplication.ReferenceActivity
import java.util.stream.Collectors

class ArtistAdapter: RecyclerView.Adapter<ArtistAdapter.MyViewHolder>() {
    lateinit var context: Context
    lateinit var artistList:ArrayList<ArtistsModal>
    lateinit var name:String

    @RequiresApi(Build.VERSION_CODES.N)
    fun getAllArtist(context: Context, list: HashMap<Long,ArtistsModal>) {
        this.context = context
        this.artistList = list.values.stream().collect(Collectors.toList()) as ArrayList<ArtistsModal>
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        var artistName: TextView

        var artistArt: ImageView
        var folderLayout: LinearLayout

        init {
            artistName = itemView.findViewById(R.id.folderName)

            artistArt = itemView.findViewById(R.id.iconImg)
            folderLayout = itemView.findViewById(R.id.folerLayout)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArtistAdapter.MyViewHolder {
        var view: View = LayoutInflater.from(parent.context).inflate(
            R.layout.all_folder_layout,
            parent,
            false
        )


        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: ArtistAdapter.MyViewHolder, position: Int) {
        var data = artistList.get(position)
        holder.artistName.text = data.ArtistName

       Glide.with(context).load(data.ArtistImg).apply(RequestOptions().placeholder(R.drawable.im).centerCrop()).into(holder.artistArt)
       // Toast.makeText(context,artistList.size.toString(), Toast.LENGTH_SHORT).show()

    }

    override fun getItemCount(): Int {
        return artistList.size
    }
}