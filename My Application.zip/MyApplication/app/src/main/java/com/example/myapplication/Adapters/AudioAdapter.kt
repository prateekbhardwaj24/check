package com.example.myapplication.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.musicplayer.Modals.AudioModal

import com.example.myapplication.R

class AudioAdapter : RecyclerView.Adapter<AudioAdapter.MyViewHolder>() {
    private var allSongList: ArrayList<AudioModal> = ArrayList()
    private lateinit var context: Context

    fun addSongs(context: Context, songList: ArrayList<AudioModal>) {
        this.allSongList = songList
        this.context = context
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var songName: TextView
        var songPath: TextView
        var songIcon: ImageView

        init {
            songName = itemView.findViewById(R.id.folderName)
            songPath = itemView.findViewById(R.id.folderPath)
            songIcon = itemView.findViewById(R.id.iconImg)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.all_folder_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        var dataModal = allSongList.get(position)
        holder.songName.text = dataModal.aName
        holder.songPath.text = dataModal.aArtist
        Glide.with(context).load(dataModal.audioIcon).apply(RequestOptions().placeholder(R.drawable.im).centerCrop()).into(holder.songIcon)

    }

    override fun getItemCount(): Int {
        return allSongList.size
    }
}