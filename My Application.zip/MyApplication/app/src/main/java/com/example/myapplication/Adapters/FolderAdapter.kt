package com.example.myapplication.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.example.musicplayer.AllFragments.AllFolders

import com.example.musicplayer.Modals.FolderModal

import com.example.myapplication.R
import com.example.myapplication.ReferenceActivity


class FolderAdapter : RecyclerView.Adapter<FolderAdapter.MyViewHolder>() {
    lateinit var context: Context
    lateinit var view: View
    var folderArrayList: ArrayList<FolderModal> = ArrayList()
    lateinit var name: String


    fun getAllFolder(context: Context, list: HashSet<FolderModal>, view: View) {
        this.context = context
        this.view = view
        this.folderArrayList = ArrayList<FolderModal>(list)
        notifyDataSetChanged()
    }


    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var folderName: TextView
        var folderPath: TextView
        var folderLayout: LinearLayout
        var folderImg: ImageView

        init {
            folderName = itemView.findViewById(R.id.folderName)
            folderPath = itemView.findViewById(R.id.folderPath)
            folderLayout = itemView.findViewById(R.id.folerLayout)
            folderImg = itemView.findViewById(R.id.iconImg)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var view: View = LayoutInflater.from(parent.context).inflate(
            R.layout.all_folder_layout,
            parent,
            false
        )
        return MyViewHolder(view)
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var data = folderArrayList.get(position)
        holder.folderName.text = data.folderName
        holder.folderPath.text = data.folderPath
        this.name = data.folderName
        holder.folderPath.visibility = View.VISIBLE
      //  Toast.makeText(context, folderArrayList.size.toString(), Toast.LENGTH_SHORT).show()
        holder.folderImg.setImageResource(R.drawable.ic_folder_icon)
        //setting click listner on folder layout to start transaction to another fragment
        holder.folderLayout.setOnClickListener {
            val intentToReferenceActivity =
                Intent(holder.folderPath.context, ReferenceActivity::class.java)
            intentToReferenceActivity.putExtra("folderName", name)
            intentToReferenceActivity.putExtra("folderPath", holder.folderPath.text)
            context.startActivity(intentToReferenceActivity)
        }
    }


    override fun getItemCount(): Int {
        return folderArrayList.size
    }

}








