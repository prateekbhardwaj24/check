package com.example.myapplication.Adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.musicplayer.AllFragments.*
import com.example.myapplication.AllFragments.AllAlbums
import com.example.myapplication.AllFragments.AllArtists
import com.example.myapplication.AllFragments.AllPlayLists
import com.example.myapplication.AllFragments.Favourites

class ViewPagerFragmentAdapter(fragmentManager: FragmentManager,lifecycle: Lifecycle):FragmentStateAdapter(fragmentManager,lifecycle) {
    override fun getItemCount(): Int {
        return 4
    }

    override fun createFragment(position: Int): Fragment {
        return when(position){

            0->{
                AllSongs()
            }
            1->{
                AllAlbums()
            }
            2->{
                AllArtists()
            }
            3->{
                AllFolders()
            }
            else -> {
                AllSongs()
            }
        }
    }
}