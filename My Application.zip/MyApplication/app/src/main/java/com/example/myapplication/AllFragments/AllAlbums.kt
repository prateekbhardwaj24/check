package com.example.myapplication.AllFragments

import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapters.AlbumAdapter
import com.example.myapplication.GridLayoutDecoration
import com.example.myapplication.Modals.AlbumsModal
import com.example.myapplication.R
import com.example.myapplication.decorationLayout
import java.util.*
import kotlin.collections.ArrayList


@Suppress("DEPRECATION")
class AllAlbums : Fragment() {
    lateinit var albumRv: RecyclerView
    var albumList: ArrayList<AlbumsModal> = ArrayList()
    lateinit var albumAdapter: AlbumAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_all_albums, container, false)
        albumRv = view.findViewById(R.id.albumRv)

        getAllAlbums()
        albumRv.layoutManager = GridLayoutManager(requireContext(), 2)
        albumAdapter = AlbumAdapter()
        var gridLayoutDecorationclass = GridLayoutDecoration()

     //   albumRv.addItemDecoration(gridLayoutDecorationclass.GridSpacingItemDecoration(3,3,true).apply {  })
        albumRv.addItemDecoration(decorationLayout(2, 3, true))
        albumRv.adapter = albumAdapter

        albumAdapter.addAlbums(requireContext(), albumList)

        return view
    }



    private fun getAllAlbums() {
        val uri: Uri = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI


        val projection = arrayOf(
            MediaStore.Audio.AlbumColumns.ALBUM,
            MediaStore.Audio.AlbumColumns.ALBUM_ART,
            MediaStore.Audio.AlbumColumns.ARTIST,
            MediaStore.Audio.AlbumColumns.ALBUM_ID,

            )
        val c: Cursor? = context?.contentResolver?.query(
            uri,
            projection,
            null,
            null,
            MediaStore.Audio.AlbumColumns.ALBUM + " DESC"
        )


        if (c != null) {
            while (c.moveToNext()) {
                // Toast.makeText(requireContext(),"fol: "+c.columnNames,Toast.LENGTH_SHORT).show()
                val albumsModal: AlbumsModal
                val albumname: String = c.getString(0)
                val artistname: String = c.getString(2)
                val albumid: String = c.getString(3)

                val albumIdc = c.getLong(c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)).toString()
                val uri = Uri.parse("content://media/external/audio/albumart")
                val artUri = Uri.withAppendedPath(uri,albumIdc).toString()


                albumsModal =
                    AlbumsModal(
                        albumName = albumname,
                        albumArt = artUri,
                        artistName = artistname,
                        albumId = albumid
                    )

                albumList.add(albumsModal)
            }
            c.close()
        }



    }


}




