package com.example.myapplication.AllFragments

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.Audio.AlbumColumns.ARTIST_ID
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapters.ArtistAdapter
import com.example.myapplication.Modals.ArtistsModal
import com.example.myapplication.R


class AllArtists : Fragment() {
    lateinit var artistRv: RecyclerView
    var artistList: HashMap<Long, ArtistsModal> = HashMap()
    lateinit var artistAdapter: ArtistAdapter


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_all_artists, container, false)

        artistRv = view.findViewById(R.id.ArtistRv)


        //get all songs
        getAllArtistData(requireContext())
        artistRv.layoutManager = LinearLayoutManager(requireContext())
        artistRv.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            )
        )
        artistAdapter = ArtistAdapter()
        artistRv.adapter = artistAdapter

        artistAdapter.getAllArtist(requireContext(), artistList)


        return view
    }

    private fun getAllArtistData(requireContext: Context) {
        val uri: Uri = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI


        val projection = arrayOf(
            MediaStore.Audio.ArtistColumns.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ARTIST_ID,

            // MediaStore.Audio.Media._COUNT,

        )
        val c: Cursor? = context?.contentResolver?.query(
            uri,
            projection,
            null,
            null,
            MediaStore.Audio.ArtistColumns.ARTIST + " ASC "
        )


        if (c != null) {
            while (c.moveToNext()) {
                // Toast.makeText(requireContext(),"fol: "+c.columnNames,Toast.LENGTH_SHORT).show()
                val artistsModal: ArtistsModal
                val artistName: String = c.getString(0)
                //  val artistTracks: String = c.getString(1)
                val artistId: Long = c.getLong(2)

                val albumIdc =
                    c.getLong(c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)).toString()
                val uri = Uri.parse("content://media/external/audio/albumart")
                val artUri = Uri.withAppendedPath(uri, albumIdc).toString()


                artistsModal =
                    ArtistsModal(
                        ArtistId = artistId.toString(), ArtistImg = artUri, ArtistName = artistName
                    )


                if (!artistList.containsKey(artistId)) {
                    artistList.put(artistId, artistsModal)
                }


            }
            c.close()
        }
    }


}