package com.example.musicplayer.AllFragments

import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.musicplayer.Modals.FolderModal

import com.example.myapplication.Adapters.FolderAdapter
import com.example.myapplication.R


class AllFolders : Fragment() {
    lateinit var folderRv: RecyclerView
    var folderList: ArrayList<FolderModal> = ArrayList()
    lateinit var folderAdapter: FolderAdapter
    var hashedFolders:HashSet<FolderModal> = HashSet()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view: View = inflater.inflate(R.layout.fragment_all_folders, container, false)

        //get ids
        folderRv = view.findViewById(R.id.allFolderRv)

        getAllFolderWithPath()
        folderRv.layoutManager = LinearLayoutManager(requireContext())
        folderAdapter = FolderAdapter()
        folderRv.adapter = folderAdapter

        folderAdapter.getAllFolder(requireContext(),hashedFolders,view)


        return view
    }


    private fun getAllFolderWithPath() {
        val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(

            MediaStore.Audio.Media.RELATIVE_PATH,
            MediaStore.Audio.AudioColumns.BUCKET_DISPLAY_NAME
        )
        val c: Cursor? = context?.contentResolver?.query(uri, projection, null, null, null)

        if (c != null) {
            while (c.moveToNext()) {
//                 Toast.makeText(requireContext(),"fol: "+c.columnNames, Toast.LENGTH_SHORT).show()
                val FolderModal: FolderModal
                val path: String = c.getString(0)
                val folder: String = c.getString(1)
                FolderModal =
                    FolderModal(folderPath = path,folderName = folder)
                hashedFolders.add(FolderModal)
                    folderList.add(FolderModal)
            }
            c.close()
        }

    }
//    fun onItemSelected(){
//        val frag=AudioReferenceFragment.newInstance()
//        (this.activity as MainActivity).replaceFragment(frag,AudioReferenceFragment.TAG)
//    }



}


