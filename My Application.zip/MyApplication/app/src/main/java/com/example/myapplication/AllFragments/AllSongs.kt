package com.example.musicplayer.AllFragments

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.musicplayer.Modals.AudioModal

import com.example.myapplication.Adapters.AudioAdapter
import com.example.myapplication.R
import java.io.File

class AllSongs : Fragment() {

    var audioList: ArrayList<AudioModal> = ArrayList()
    var folderList: ArrayList<String> = ArrayList()
    lateinit var allSongsRv: RecyclerView
    lateinit var audioAdapter: AudioAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view:View = inflater.inflate(R.layout.fragment_all_songs, container, false)
        // Inflate the layout for this fragment

        allSongsRv= view.findViewById(R.id.AllSongsRv)


        //get all songs
        audioList = getAllAudioFromDevice(requireContext())
        allSongsRv.layoutManager = LinearLayoutManager(requireContext())
        allSongsRv.addItemDecoration(DividerItemDecoration(requireContext(),DividerItemDecoration.VERTICAL))
        audioAdapter = AudioAdapter()
        allSongsRv.adapter = audioAdapter

        audioAdapter.addSongs(requireContext(), audioList)


        return view
    }



    fun getAllAudioFromDevice(context: Context): ArrayList<AudioModal> {
        val tempAudioList: ArrayList<AudioModal> = ArrayList()
        val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI


        val projection = arrayOf(
            MediaStore.Audio.AudioColumns.DATA,
            MediaStore.Audio.AudioColumns.TITLE,
            MediaStore.Audio.AudioColumns.ALBUM,
            MediaStore.Audio.AudioColumns.DISPLAY_NAME,

            //artitst

            MediaStore.Audio.ArtistColumns.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,

            //Albums
            MediaStore.Audio.AlbumColumns.ALBUM,
            MediaStore.Audio.AlbumColumns.ARTIST,
            MediaStore.Audio.AlbumColumns.ALBUM_ID,
        )
       val c: Cursor? = context.contentResolver.query(uri, projection, MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.AlbumColumns.ARTIST+" ASC")

        if (c != null) {
            while (c.moveToNext()) {
               // Toast.makeText(requireContext(),"fol: "+c.columnNames,Toast.LENGTH_SHORT).show()
                val audioModel: AudioModal
                val path: String = c.getString(0)
                val name: String = c.getString(1)
                val album: String = c.getString(2)
                val displayName: String = c.getString(3)

                val artist: String = c.getString(4)
               // val noOfAlbum: String = c.getString(5)
              //  val noOfTrack: String = c.getString(6)

                val Albumpath: String = c.getString(5)
               // val noOfSongAlbum: String = c.getString(6)
                val NameArtitstAlbum: String = c.getString(6)
                val AlbumId: String = c.getString(7)


                val albumIdc =
                    c.getLong(c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)).toString()
                val uri = Uri.parse("content://media/external/audio/albumart")
                val artUri = Uri.withAppendedPath(uri, albumIdc).toString()



                audioModel =
                    AudioModal(aName = name, aAlbum = album, aArtist = artist, aPath = path,displName = displayName,albumPath = Albumpath,albumId = AlbumId,nameArtistAlbum = NameArtitstAlbum,audioIcon = artUri)
                Log.d("Name :$name -> ", " Album :$album")
                Log.d("Path :$path -> ", " Artist :$artist")

                tempAudioList.add(audioModel)
            }
            c.close()
        }
        return tempAudioList
    }

}