package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.musicplayer.Modals.AudioModal
import com.example.myapplication.Modals.FolderDataModal

class FolderSongsAdapter: RecyclerView.Adapter<FolderSongsAdapter.MyViewHolder>() {

    private var folderSongList: ArrayList<FolderDataModal> = ArrayList()
    private lateinit var context: Context

    fun addSongs(context: Context, songList: ArrayList<FolderDataModal>) {
        this.folderSongList = songList
        this.context = context
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        lateinit var songName: TextView
        lateinit var songPic: ImageView

        init {
            songName = itemView.findViewById(R.id.folderName)
            songPic = itemView.findViewById(R.id.iconImg)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.all_folder_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var dataModal = folderSongList.get(position)

        holder.songName.text = dataModal.nameOfFile
        Glide.with(context).load(dataModal.uriPic).apply(RequestOptions().placeholder(R.drawable.im).centerCrop()).into(holder.songPic)

    }

    override fun getItemCount(): Int {
        return folderSongList.size
    }
}