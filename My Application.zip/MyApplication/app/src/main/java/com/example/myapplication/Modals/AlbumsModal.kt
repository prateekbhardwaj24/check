package com.example.myapplication.Modals

import android.graphics.Bitmap

data class AlbumsModal(
    var albumName:String,
    var albumArt: String,
    var artistName: String,
    var albumId: String,


)
