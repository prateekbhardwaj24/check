package com.example.myapplication.Modals

data class ArtistsModal(
    var ArtistName:String,
    var ArtistId:String,
    var ArtistImg:String
)
