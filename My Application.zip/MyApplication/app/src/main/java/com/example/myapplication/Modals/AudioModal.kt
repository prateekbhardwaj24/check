package com.example.musicplayer.Modals

data class AudioModal(
    var aPath:String,
    var aName:String,
    var aAlbum:String,
    var displName:String,



    var aArtist:String,



    var albumPath:String, //this is equal to aAlbum = album name
var audioIcon:String,
    var nameArtistAlbum:String,
    var albumId:String
)
