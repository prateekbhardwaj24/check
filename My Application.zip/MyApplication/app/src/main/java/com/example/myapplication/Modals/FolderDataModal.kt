package com.example.myapplication.Modals

data class FolderDataModal(
    var nameOfFile:String,
    var uriPic:String
)
