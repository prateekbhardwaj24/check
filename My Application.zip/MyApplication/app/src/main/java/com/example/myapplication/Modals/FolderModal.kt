package com.example.musicplayer.Modals

data class FolderModal(
    var folderPath:String,
    var folderName:String
)
