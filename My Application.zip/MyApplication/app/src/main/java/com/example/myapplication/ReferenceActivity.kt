package com.example.myapplication

import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.MediaStore.MediaColumns.RELATIVE_PATH
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.musicplayer.Modals.AudioModal
import com.example.myapplication.Modals.FolderDataModal
import java.io.File


class ReferenceActivity : AppCompatActivity() {

    lateinit var folderSongsRv:RecyclerView
    var audioList: ArrayList<FolderDataModal> = ArrayList()
    lateinit var folderSongAdapter: FolderSongsAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reference)
        setSupportActionBar(findViewById(R.id.toolbar))

        folderSongsRv = findViewById(R.id.folderRv)

        //get intent data

        var fName = intent.getStringExtra("folderName").toString()
        var fPath = intent.getStringExtra("folderPath").toString()


        getAllSongsOfFolder(fName, fPath)

        folderSongsRv.layoutManager = LinearLayoutManager(this)
        folderSongAdapter = FolderSongsAdapter()
        folderSongsRv.adapter = folderSongAdapter

        folderSongAdapter.addSongs(this, audioList)


    }

    private fun getAllSongsOfFolder(fName: String, fPath: String) {

        val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.AudioColumns.RELATIVE_PATH,
            MediaStore.Audio.AudioColumns.TITLE,
            MediaStore.Audio.AudioColumns.ALBUM_ID,
            MediaStore.Audio.ArtistColumns.ARTIST,

        )

        val path: String =
            Environment.getExternalStorageDirectory().path+ "/" + fPath
       // val selectionS =    MediaStore.Audio.AudioColumns.RELATIVE_PATH.toString() + " LIKE $fPath"
        Log.d("Files", "Path: $path")
       // Toast.makeText(this,"path : "+  selectionS+"  and f: "+fPath,Toast.LENGTH_SHORT).show()
        val directory = File(path)
        val files = directory.listFiles()

        val cursor: Cursor? = this.contentResolver?.query(uri,projection,null,null,null)



        if (cursor != null) {
            Log.d("kkkk", "Path: $path")
            while (cursor.moveToNext()) {
                Log.d("llll", "Path: $path")
                 //Toast.makeText(this,"fol: "+cursor.columnNames,Toast.LENGTH_SHORT).show()
                val folderDatamodal: FolderDataModal

                val sPath: String = cursor.getString(0)
                val sName: String = cursor.getString(1)
                val sPic: String = cursor.getString(2)

                if (sPath.equals(fPath)){
                    val albumIdc =
                        cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)).toString()
                    val uri = Uri.parse("content://media/external/audio/albumart")
                    val artUri = Uri.withAppendedPath(uri, albumIdc).toString()

                    folderDatamodal = FolderDataModal(nameOfFile = sName,uriPic = artUri)

                    audioList.add(folderDatamodal)
                   // Toast.makeText(this,"tr: true",Toast.LENGTH_SHORT).show()
                }
               // Toast.makeText(this,"tr: "+sPath,Toast.LENGTH_SHORT).show()

            }
            Toast.makeText(this, fPath + " in " + cursor.count, Toast.LENGTH_SHORT).show()

        }else{
            Toast.makeText(this, fPath + " and " + cursor, Toast.LENGTH_SHORT).show()

        }


    }
}

