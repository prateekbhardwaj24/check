package com.example.myapplication.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.musicplayer.Modals.AudioModal
import com.example.myapplication.Adapters.AudioAdapter
import com.example.myapplication.Adapters.ViewPagerFragmentAdapter
import com.example.myapplication.R
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class HomeFragment : Fragment() {


    var audioList: ArrayList<AudioModal> = ArrayList()
    lateinit var allSongsRv: RecyclerView
    lateinit var audioAdapter: AudioAdapter

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
       // homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)

        val tabLayout = root.findViewById<TabLayout>(R.id.pagerTabsLayout)
        val viewPager = root.findViewById<ViewPager2>(R.id.slidingViewPager)

        val pagerAdapter = ViewPagerFragmentAdapter((activity as AppCompatActivity).supportFragmentManager, lifecycle)

        viewPager.adapter = pagerAdapter

        TabLayoutMediator(tabLayout, viewPager){ tab, position->
            when(position){

                0 -> {
                    tab.text = "Tracks"
                }
                1-> {
                    tab.text = "Albums"
                }
                2 -> {
                    tab.text = "Artists"
                }
                3 -> {
                    tab.text = "Folder"
                }
            }
        }.attach()

        return root
    }
}